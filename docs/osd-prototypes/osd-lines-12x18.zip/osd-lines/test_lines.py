#!/usr/bin/env python3
"""Host-side correctness checks; requires Python 3 and a C compiler."""
import ctypes as C
from pathlib import Path
import random
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def run(tile_w=12, tile_h=18):
    with tempfile.TemporaryDirectory() as tmp:
        so = Path(tmp) / "lines.so"
        subprocess.run([
            "cc", "-std=c99", "-Wall", "-Wextra", "-Werror", "-pedantic",
            "-O2", "-fPIC", "-shared", f"-DOSD_TILE_W={tile_w}",
            f"-DOSD_TILE_H={tile_h}", str(ROOT / "osd_lines.c"), "-o", str(so)
        ], check=True)
        lib = C.CDLL(str(so))

        class Canvas(C.Structure):
            _fields_ = [("pixels", C.POINTER(C.c_uint8)),
                        ("dirty", C.POINTER(C.c_uint8)),
                        ("cols", C.c_uint8), ("rows", C.c_uint8),
                        ("tile_count", C.c_uint16)]

        ptr = C.POINTER(Canvas)
        lib.osd_canvas_init.argtypes = [ptr, C.c_uint8, C.c_uint8,
                                      C.POINTER(C.c_uint8), C.c_uint16,
                                      C.POINTER(C.c_uint8), C.c_uint16]
        lib.osd_canvas_init.restype = C.c_uint8
        lib.osd_clear.argtypes = [ptr]
        lib.osd_mark_all_dirty.argtypes = [ptr]
        lib.osd_pixel.argtypes = [ptr, C.c_int16, C.c_int16, C.c_uint8]
        lib.osd_line.argtypes = [ptr] + [C.c_int16] * 4 + [C.c_uint8]
        upload_type = C.CFUNCTYPE(C.c_uint8, C.c_uint16,
                                 C.POINTER(C.c_uint8), C.c_uint16, C.c_void_p)
        lib.osd_flush.argtypes = [ptr, upload_type, C.c_void_p]
        lib.osd_flush.restype = C.c_uint16

        cols, rows = 4, 3
        width, height = cols * tile_w, rows * tile_h
        tile_bytes = (tile_w * tile_h + 7) // 8
        size = cols * rows * tile_bytes
        guard = (C.c_uint8 * (size + 16))(*([0xA5] * (size + 16)))
        pixels = C.cast(C.byref(guard, 8), C.POINTER(C.c_uint8))
        flags = (C.c_uint8 * ((cols * rows + 7) // 8))()
        canvas = Canvas()
        assert not lib.osd_canvas_init(C.byref(canvas), cols, rows,
                                      pixels, size - 1, flags, len(flags))
        assert not lib.osd_canvas_init(C.byref(canvas), 0, rows,
                                      pixels, size, flags, len(flags))
        assert lib.osd_canvas_init(C.byref(canvas), cols, rows,
                                  pixels, size, flags, len(flags))
        assert bytes(flags) == b"\xff\x0f"
        seen = []

        @upload_type
        def upload(tile, data, count, user):
            seen.append((tile, bytes(data[:count])))
            return 1

        @upload_type
        def fail(tile, data, count, user):
            return 0

        assert lib.osd_flush(C.byref(canvas), fail, None) == 0
        assert bytes(flags) == b"\xff\x0f"
        assert lib.osd_flush(C.byref(canvas), upload, None) == cols * rows
        assert all(len(data) == tile_bytes for _, data in seen)
        assert bytes(flags) == b"\x00\x00"
        assert lib.osd_flush(C.byref(canvas), upload, None) == 0

        def reference(x0, y0, x1, y1):
            # Closed-form integer rounding, independent of the cursor/error loop.
            dx, dy = abs(x1 - x0), abs(y1 - y0)
            sx, sy = (1 if x1 >= x0 else -1), (1 if y1 >= y0 else -1)
            major, minor = max(dx, dy), min(dx, dy)
            points = set()
            for i in range(major + 1):
                j = (i * minor + (major - 1) // 2) // major if major else 0
                x, y = ((x0 + sx * i, y0 + sy * j) if dx >= dy
                        else (x0 + sx * j, y0 + sy * i))
                if 0 <= x < width and 0 <= y < height:
                    points.add((x, y))
            return points

        def actual():
            result = set()
            for y in range(height):
                for x in range(width):
                    tile = (y // tile_h) * cols + x // tile_w
                    bit = (y % tile_h) * tile_w + x % tile_w
                    if pixels[tile * tile_bytes + bit // 8] & (0x80 >> (bit % 8)):
                        result.add((x, y))
            return result

        cases = [
            (0, 0, 0, 0), (0, 0, width - 1, height - 1),
            (width - 1, height - 1, 0, 0),
            (-32768, 0, 32767, 0), (0, -32768, 0, 32767),
            (-32768, -32768, 32767, 32767),
            (32767, -32768, -32768, 32767),
            (-10, -10, -1, -1), (width, 0, width, height),
            (tile_w - 1, tile_h - 1, tile_w, tile_h),
        ]
        rng = random.Random(2795)
        cases.extend(tuple(rng.randint(-60, 110) for _ in range(4))
                     for _ in range(500))
        for endpoints in cases:
            lib.osd_clear(C.byref(canvas))
            lib.osd_line(C.byref(canvas), *endpoints, 1)
            assert actual() == reference(*endpoints), (tile_w, tile_h, endpoints)
            lib.osd_line(C.byref(canvas), *endpoints, 0)
            assert not actual()
            assert list(guard[:8]) == [0xA5] * 8
            assert list(guard[-8:]) == [0xA5] * 8

        # One pixel, exact canonical packing and dirty tile; redraw is a no-op.
        lib.osd_flush(C.byref(canvas), upload, None)
        lib.osd_pixel(C.byref(canvas), tile_w, tile_h, 1)
        assert pixels[(cols + 1) * tile_bytes] == 0x80
        assert flags[0] == 1 << (cols + 1)
        assert lib.osd_flush(C.byref(canvas), fail, None) == 0
        assert flags[0] == 1 << (cols + 1)
        assert lib.osd_flush(C.byref(canvas), upload, None) == 1
        lib.osd_pixel(C.byref(canvas), tile_w, tile_h, 1)
        assert lib.osd_flush(C.byref(canvas), upload, None) == 0
        lib.osd_pixel(C.byref(canvas), tile_w, tile_h, 0)
        assert lib.osd_flush(C.byref(canvas), upload, None) == 1
        print(f"PASS: {tile_w}x{tile_h}, {len(cases)} lines, packing, guards, dirty/upload retry")


if __name__ == "__main__":
    for dimensions in [(12, 18), (8, 8), (7, 5), (1, 1), (32, 32)]:
        run(*dimensions)
