#include "osd_lines.h"

#define COLS 32
#define ROWS 12

/* On SDCC/8051 put the buffers in XDATA. No heap or full second framebuffer. */
#ifdef __SDCC_mcs51
static __xdata uint8_t pixels[OSD_BITMAP_BYTES(COLS, ROWS)];
static __xdata uint8_t dirty[OSD_DIRTY_BYTES(COLS, ROWS)];
static __xdata osd_canvas canvas;
#else
static uint8_t pixels[OSD_BITMAP_BYTES(COLS, ROWS)];
static uint8_t dirty[OSD_DIRTY_BYTES(COLS, ROWS)];
static osd_canvas canvas;
#endif

uint8_t scope_init(void)
{
    return osd_canvas_init(&canvas, COLS, ROWS,
                            pixels, sizeof pixels, dirty, sizeof dirty);
}

/* y[] contains screen y coordinates, one per horizontal pixel.
 * Supply an adapter that writes one tile to the Realtek OSD font SRAM.
 * Configure the OSD map separately: each cell uses its own matching tile ID.
 */
void scope_frame(const int16_t *y, uint16_t count,
                 osd_upload_fn upload, void *user)
{
    uint16_t x;
    if (count > COLS * OSD_TILE_W) count = COLS * OSD_TILE_W;
    osd_clear(&canvas);
    if (count == 1) osd_pixel(&canvas, 0, y[0], 1);
    for (x = 1; x < count; ++x)
        osd_line(&canvas, (int16_t)(x - 1), y[x - 1], (int16_t)x, y[x], 1);
    (void)osd_flush(&canvas, upload, user);
}
