# DDC colour controls #371 review

Proposed local commit: 351d945 on review/371-rgb-user.
Base: 3326a1d6f78e7c676947bf7d82f35eb6d9f7166e.

Read REVIEW.md for the recommendation, alternatives, MCCS semantics, preset evidence and decisions.
Read VALIDATION.md for the 1,452-check RGB result, other passes, and blocked checks.
0001-colour-controls.patch is a git format patch containing the implementation, tests and these reports.
Apply to a checkout of the base with git am. Rebuild and run the full project gates before merging.
The tooling wrapper only records a workaround for local generated-object naming; it is outside the repository patch.

No gains invented or changed. No remote branch/PR was published. Nothing merged, flashed, or changed on a monitor.
Approval is required before merging or physical-monitor operations. No flashable image is included.
