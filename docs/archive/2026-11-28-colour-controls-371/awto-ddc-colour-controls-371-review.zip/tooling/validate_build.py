"""Local validation only: shorten two generated object names that collide in ASlink's map.
Does not edit firmware sources or bypass the layout/size validation.
"""
import sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
import fw_build as F
original=F.split_xseg
def split_xseg(asm_dir, compact=False):
    for old,new in [('RL6449_Series_ColorOutputGammaChannelCtrl','ColorOutputGammaChannelCtrl'),('RL6449_Series_ColorOutputGammaAdjust','ColorOutputGammaAdjust')]:
        p=asm_dir/(old+'.rel')
        if p.exists():
            p.rename(asm_dir/(new+'.rel'))
            listing=asm_dir/(old+'.lst')
            if listing.exists():
                (asm_dir/(new+'.lst')).write_bytes(listing.read_bytes())
    return original(asm_dir,compact)
F.split_xseg=split_xseg
raise SystemExit(F.main())
